// logic.js

jQuery(document).ready(function($) {

	// YOUR SCRIPT HERE
	
});
